<div id="membrete">
					<div class="contenedor">
						<div class="membrete-margin">
							<ul>
								<li><a href="http://zulia.gob.ve"><div class="loteria"></div></a></li>
								<li><a href="http://gobiernoenlinea.gob.ve"><div class="gobierno"></div></a></li>
							    <li><a href="http://zulia.gob.ve/"><div class="zulia"></div></a></li>
							</ul>
						</div>
					</div>
				</div>