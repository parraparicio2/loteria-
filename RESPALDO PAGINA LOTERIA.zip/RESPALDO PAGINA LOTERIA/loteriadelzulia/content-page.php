<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
 <div class="noticia">
                                        <p class="title2"><?php the_title(); ?></p>
                        <div class="contenido">
                                <p><?php the_content(); ?></p>
                            </div>
                        </div>
                    </div>