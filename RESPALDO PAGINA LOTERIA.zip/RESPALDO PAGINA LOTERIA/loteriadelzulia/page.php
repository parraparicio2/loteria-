<?php
/**
 * Template Name: News
 *
 * Description: Twenty Twelve loves the no-sidebar look as much as
 * you do. Use this page template to remove the sidebar from any page.
 *
 * Tip: to remove the sidebar from all posts and pages simply remove
 * any active widgets from the Main Sidebar area, and the sidebar will
 * disappear everywhere.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Lotería del Zulia</title>
    <link rel="stylesheet" type="text/css" href="../wp-content/themes/loteriadelzulia/css/normalize.css">
    <link rel="stylesheet" type="text/css" href="../wp-content/themes/loteriadelzulia/css/style.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../wp-content/themes/loteriadelzulia/css/icons_conalot.css">
    <link rel="stylesheet" href="../wp-content/themes/loteriadelzulia/css/animation.css"><!--[if IE 7]>
    <link rel="stylesheet" href="css/icons_conalot-ie7.css"><![endif]-->
    <script type="text/javascript" src="../wp-content/themes/loteriadelzulia/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="../wp-content/themes/loteriadelzulia/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="../wp-content/themes/loteriadelzulia/js/scripts.js"></script>
    <script type="text/javascript" src="../wp-content/themes/loteriadelzulia/js/jquery.simplyscroll.js"></script>
    <script type="text/javascript" src="../wp-content/themes/loteriadelzulia/js/jquery.tools.min.js"></script>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
    <section id="page">
        <nav>
            <div id="head">
                <?php include($_SERVER["DOCUMENT_ROOT"]."/wp-content/themes/loteriadelzulia/membrete.php"); ?>
                <?php include( $_SERVER["DOCUMENT_ROOT"]."/wp-content/themes/loteriadelzulia/menu.php"); ?>
            </div>
        </nav>
        <section id="body">
            <div class="contenedor">
                <div class="noticias newsbg">
                    <div class="noticias-margin">
                        <ul>
                            <li class="td100">
                                <div class="noticia-margin">
                                    <?php while ( have_posts() ) : the_post(); ?>
                                        <?php get_template_part( 'content', 'page' ); ?>
                                    <?php endwhile; // end of the loop. ?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="page-margin">
                    <div class="redes">
                        <p><a href="https://twitter.com/LoteriaZuliaGBZ"><i class="icon-twitter tw"></i></a> <a href="https://www.facebook.com/pages/Loter%C3%ADa-del-Zulia/138491336352632"><i class="icon-facebook fb"></i></a></p>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <p>Copyright (c) 2013. Lotería del Zulia. Todos los derechos reservados.</p>
        </footer>
    </section>
</body>
</html>