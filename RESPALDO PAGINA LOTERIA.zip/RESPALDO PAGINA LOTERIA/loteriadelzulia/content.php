<?php
/**
 * The default template for displaying content. Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<li>
    <div class="news">
    	<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'twentytwelve' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">
    		<div class="new" style="background-image:url(<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>); background-size: auto 100%; background-position: 50%;">
	        	<p><span class="fecha"><?php the_date('F, j') ?></span><p>
	            <p class="texto_position"><span class="texto"><?php the_title(); ?></span></p>
	        </div>
	    </a>
    </div>
</li><!---->