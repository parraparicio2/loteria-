var called_from_bridge = false;
$.evalFile(app.path + '/Presets/Scripts/Tych%20Panel/Tych%20Panel%20Only/tych.jsx');
t.layout_and_composite(COLUMN, LEFT);
