﻿var WHITE = Array(255, 255, 255);
var BLACK = Array(0, 0, 0);

var TOP = 0;
var RIGHT = 1;
var BOTTOM = 2;
var LEFT = 3;

var TOP_LEFT = 4;
var TOP_RIGHT = 5;
var BOTTOM_RIGHT = 6;
var BOTTOM_LEFT = 7;

var ROW = 8;
var COLUMN = 9;
