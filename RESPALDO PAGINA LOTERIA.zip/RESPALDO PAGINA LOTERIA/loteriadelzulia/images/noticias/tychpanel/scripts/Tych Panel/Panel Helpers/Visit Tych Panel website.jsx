var plugin_dir = localize('$$$/LocalizedFilenames.xml/SourceDirectoryName/id/Extras/[LOCALE]/[LOCALE]_Plug-ins/value=Plug-ins');
var html_file = app.path.toString() + "/" + plugin_dir + "/Panels/Tych Panel/content/Tych Panel.assets/index.html";
File(html_file).execute();
