﻿<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="Keywords" content="loteria del zulia, loteria, zulia, donacion, loteriadelzulia" >
    <meta name="keywords" content="resultados de las loter&iacute;as, loter&iacute;a del zulia, loter&iacute;as de venezuela,  triple zulia, sorteo de la loter&iacute;a, triples de venezuela, triple,  loter&iacute;a, sorteo, nuestro triple,  triple zulia multicolor, zulia multicolor,  triple y signo" />
	<meta name="google-site-verification" content="u46ml06OSPyRzymg6V9_rcRVc4WHjL4mc0nfwMprPLU" />
	<title>Lotería del Zulia</title>
	<link rel="stylesheet" type="text/css" href="wp-content/themes/loteriadelzulia/css/normalize.css">
	<link rel="stylesheet" type="text/css" href="wp-content/themes/loteriadelzulia/css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="wp-content/themes/loteriadelzulia/css/icons_conalot.css">
    <link rel="stylesheet" href="wp-content/themes/loteriadelzulia/css/animation.css"><!--[if IE 7]>
    <link rel="stylesheet" href="css/icons_conalot-ie7.css"><![endif]-->
	<script type="text/javascript" src="wp-content/themes/loteriadelzulia/js/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="wp-content/themes/loteriadelzulia/js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="wp-content/themes/loteriadelzulia/js/scripts.js"></script>
	<script type="text/javascript" src="wp-content/themes/loteriadelzulia/js/jquery.simplyscroll.js"></script>
	<script type="text/javascript" src="wp-content/themes/loteriadelzulia/js/jquery.tools.min.js"></script>
    <script type="text/javascript">// <![CDATA[
     function search_cod_autorizacion() { var cod_autorizacion = document.getElementById("nro_ticket").value; window.open("http://www.operadorabanklot.com/sicolot/action/consulta_ticket?cod_autorizacion="+cod_autorizacion, "_blank", "width=900,height=500"); }
// ]]&gt;
    </script></p>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
	<?php //include("modales.php"); ?>
	<section id="page">
		<nav>
			<div id="head">
				<?php include("membrete.php"); ?>
				<?php include("menu.php"); ?>
			</div>
		</nav>
		<section id="body">
			<div class="contenedor">
				<div class="banners">
					<div class="head">
						<div class="logo_bicentenario"></div>
					</div>
					<div class="header">
						<ul>
							<li>
								<div class="banner banner1"></div>
							</li><!--
						 --><li>
						 		<div class="banner banner2"></div>
						 	</li><!--
						 --><li>
						 		<div class="banner banner3"></div>
							</li>
						</ul>
					</div>
				</div>
				<div class="noticias">
					<div class="noticias-margin">
						<ul>
							<?php
							$i = 1;
										$args = array(
										    'post_type' => 'post',
										    'numberposts' => 3,
										    'post_status' => null,
										    'category' => 1,
										    ); 
										$pages = get_posts($args);
										if ($pages) {
										    foreach ($pages as $post) {
										    	setup_postdata($post);
										    	?>
							<li>
								<div class="<?php if($i == 1) echo 'noticia-margin-1'; elseif($i == 2) echo 'noticia-margin-2'; else echo 'noticia-margin-3'; ?>">
									<div class="noticia">
											<div class="img" style="background-image:url(<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>); background-size: 100%; background-position: 50%;">
											<div class="datos">
												<div class="fecha-container"><p class="fecha"><?php list($fecha) = split(" ",$post->post_date); echo $fecha; ?></p></div>
												<p class="title"><a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a></p>
											</div>
										</div>
									</div>
								</div>
							</li><!---->
							<?php $i++; }} ?>
						</ul>
					</div>
				</div>
				<div class="page-margin">
					<div class="noticias-ver">
						<p><a href="noticias" class="btn">Ver más noticias</a></p>
					</div>
				</div>
				<div class="page-margin" style="width:100%; text-align:center">
                    <div style="width:50%; height:200px; overflow:visible; float:left">
                        <div id="contenedor" style="height: auto; "><a href="http://www.conalot.gob.ve/"><img class="aligncenter size-medium wp-image-958" alt="CONALOT" src="http://loteriadelzulia.org/wp-content/uploads/2013/07/CONALOT-300x300.jpeg" width="300" height="200" /></a></div>
                        </div>
                    </div>
                    <div style=" width:48%; height:200px; overflow:visible; float:left; ">
                        <div style="background-color: #4f65c3; height: 150px; width: 300px; border-radius: 5px; margin-left:10%; -moz-box-shadow: 3px 3px 4px #111; -webkit-box-shadow: 3px 3px 4px #111; box-shadow: 3px 3px 4px #111;; ">
							<p style="padding: 10px; text-align: center; font-weight: bold; color:#FFF">Para consulta de ticket, por favor ingrese el Número de autorización</p>
							
								<div style="height: 50px; margin: auto; width: 300px;">
									<p style="text-align: center;"><input id="nro_ticket" style="border: 1px solid black; width: 200px; background:#FFF" type="text" name="nro_ticket" /></p>
								</div>
                         </div>

						<div style="margin-left: 135px;">
							<input class="horariobtn" style="width: 100px; margin-top: -15%;" onclick="search_cod_autorizacion()" type="button" value="Buscar" />
						</div><!--page-margin-->
			        </div>

				<div class="page-margin">
					<div class="redes">
						<p><a href="https://twitter.com/LoteriaZuliaGBZ"><i class="icon-twitter tw"></i></a> <a href="https://www.facebook.com/pages/Loter%C3%ADa-del-Zulia/138491336352632"><i class="icon-facebook fb"></i></a></p>
					</div>
				</div>
				<footer>
					<p>Copyright (c) 2013. Lotería del Zulia. Todos los derechos reservados.</p>
				</footer>

		</section>
	</section>
	
	
	
</body>
</html>