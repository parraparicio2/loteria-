<div id="menu">
                    <div class="contenedor">
                        <ul>
                            <?php 

                                    echo '<input id="page" type="hidden" value="'.get_the_title().'"/>';

                                ?>
                            <li id="m1" class="short">
                                <a id="inicio" href="http://loteriadelzulia.gob.ve" class="selected"><p><i class="icon-home"></i></p></a>
                            </li><!--
                         --><li id="m2" class="normal">
                                <a id="noticias" href="http://loteriadelzulia.gob.ve/noticias"><p>Noticias</p></a>
                            </li><!--
                         --><li id="m3" class="normal">
                                <a id="loteria" href="#" class="links"><p>La Lotería</p></a>
                                <div class="inset">
								    <a href="http://loteriadelzulia.gob.ve/resena">Rese&ntilde;a Historica</a>
                                    <a href="http://loteriadelzulia.gob.ve/mision">Misión</a>
                                    <a href="http://loteriadelzulia.gob.ve/vision">Visión</a>
                                    <a href="http://loteriadelzulia.gob.ve/objetivos">Objetivos</a>
                                    <a href="http://loteriadelzulia.gob.ve/leyes">Leyes</a>
                                </div>
                            </li><!--
                         --><li id="m4" class="normal">
                                <a id="beneficencia" href="#" class="links"><p>Beneficencia</p></a>
                                <div class="inset">
                                    <a href="#">Ayudas</a>
                                    <a href="http://loteriadelzulia.gob.ve/requisitos">Requisitos</a>
                                </div>
                            </li><!--
                         --><li id="m5" class="normal">
                                <a id="productos" href="#" class="links"><p>Sorteos</p></a>
                                <div class="inset">
                                    <a href="http://loteriadelzulia.gob.ve/productos">Triple Zulia</a>
                                </div>
                            </li><!--
                         --><li id="m6" class="normal"><a id="contacto" href="http://loteriadelzulia.gob.ve/contacto"><p>Contacto</p></a></li>
                        </ul>
                    </div>
                </div>