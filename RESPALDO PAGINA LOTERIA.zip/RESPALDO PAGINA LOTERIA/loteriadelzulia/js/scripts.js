var num_options = 0;
var contenedor_size = 960;
var num_banner = 3;
var i = 1;

$(document).on("ready",init);
function init(e)
{
	$("#page").ahdplugin("init");
	$("#modal1").ahdplugin("init");
	$("#menu li").each(function(){
		num_options++;
	});
	porcent = ((contenedor_size/num_options)/contenedor_size)*100;
	pshort = porcent-8;
	pnormal = porcent+(8/(num_options-1));
	$("#menu .short").css({"width":pshort+"%"});
	$("#menu .normal").css({"width":pnormal+"%"});
	/* Menu */
	$("#menu ul li").hover(function(){
		id = $(this).attr("id");
		$("#menu #"+id+" .inset").slideDown();
		$("#menu #"+id).css({"background-image":"url(images/menu/sombra.png)"});
	},function(){
		$("#menu #"+id).css({"background-image":"none"});
		$("#menu #"+id+" .inset").slideUp();
	});
	/********/
	var logo_height = $("#body .head").height()-$("#body .head .logo_bicentenario").height()-20;
	$("#body .head .logo_bicentenario").css({"top":logo_height,"left":20});
	/********/
	/********/
	$("#body .header ul").css({"width":contenedor_size*num_banner});
	$("#body .header .banner"+i).stop().animate({"left":-500},20000);
	setInterval(function(){
		$("#body .header").ahdplugin("headerSliderMove",i);
		i++;
		$("#body .header .banner"+i).css({"left":0});
		$("#body .header .banner"+i).stop().animate({"left":-500},20000);
		if(i == num_banner) i = 0;
	},5000);
	/********/
	load_news();
	function load_news(){
		var news_title_h_1 = $("#body .noticia-margin-1 .datos").height()-$("#body .noticia-margin-1 .title").height()-$("#body .noticia-margin-1 .fecha-container").height();
		$("#body .noticia-margin-1 .title").css({"top":news_title_h_1});
		var news_title_h_2 = $("#body .noticia-margin-2 .datos").height()-$("#body .noticia-margin-2 .title").height()-$("#body .noticia-margin-2 .fecha-container").height();
		$("#body .noticia-margin-2 .title").css({"top":news_title_h_2});
		var news_title_h_3 = $("#body .noticia-margin-3 .datos").height()-$("#body .noticia-margin-3 .title").height()-$("#body .noticia-margin-3 .fecha-container").height();
		$("#body .noticia-margin-3 .title").css({"top":news_title_h_3});
	}
	/********/
	$("#menu ul li a").each(function(){
		$(this).removeClass("selected");
	});
	var val = $("#menu #page").attr("value");
	if(val == "Productos"){
		$("#menu #productos").addClass("selected");
	}else if(val == "Noticias"){
		$("#menu #noticias").addClass("selected");
	}else if(val == "Misión" || val == "Visión" || val == "Objetivos" || val == "Leyes"){
		$("#menu #loteria").addClass("selected");
	}else if(val == "Contacto"){
		$("#menu #contacto").addClass("selected");
	}else{
		$("#menu #inicio").addClass("selected");
	}
	window.onresize = function(){}
	$("#modal1").css({"display":"block"});
	$("#modal1").delay(100).animate({"opacity":1},500,'easeInOutExpo');
	init_modal();
	/**/
	$("#modal1 .modal-close").on("click",close_modal);
	$("#modal1 .bg").on("click",close_modal);
	function close_modal(){
		$("#modal1").stop().animate({"opacity":0},500,'easeInOutExpo',function(){
			$("#modal1").css({"display":"none"});
		});
	}
}
function init_modal() {
	h = $("#modal1 .noticias").height()+$("#modal1 .contenido .controles").height()+$("#modal1 .footer").height();
	w = 800;
	$("#modal1 .contenedor").css({"width":w,"height":h,"top":(h_screen()/2)-(h/2)-$("#modal1 .contenido .controles").height(),"left":(w_screen()/2)-(w/2)});
}
function h_screen(){
	if(typeof(window.innerHeight) == "number"){ //Non-IE
		return window.innerHeight;
	}else if(document.documentElement && document.documentElement.clientHeight){ //IE 6+ in 'standards compliant mode'
		return document.documentElement.clientHeight;
	}else if(document.body && document.body.clientHeight){ //IE 4 compatible
		return document.body.clientHeight;
	}
	return 0;
}
function w_screen(){
	if(typeof(window.innerWidth) == "number"){ //Non-IE
		return window.innerWidth;
	}else if(document.documentElement && document.documentElement.clientWidth){ //IE 6+ in 'standards compliant mode'
		return document.documentElement.clientWidth;
	}else if(document.body && document.body.clientWidth){ //IE 4 compatible
		return document.body.clientWidth;
	}
	return 0;
}
(function( $ ) {
	var methods = {
		init : function( config ) {
	    	config = jQuery.extend({
	    		container : '',
	    		box : '',
	    		type : '_content'
	    	}, config); 
	    	return $(this).each(function ( ){
	    		config.container = $(this);
	    		config.container.css({"min-height":h_screen()});
	    	});
	    },
	    headerSliderMove : function (num){
	    	return this.stop().animate({
		    	"scrollLeft":(contenedor_size*num)
		    },800,'easeInOutExpo');
	    }
	};
	$.fn.ahdplugin = function( method ) {
  		if ( methods[method] ) {
	    	return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
	    } else if ( typeof method === 'object' || ! method ) {
	    	return methods.init.apply( this, arguments );
	    } else {
	    	$.error( 'Method ' +  method + ' does not exist on jQuery.tooltip' );
	    }
  	};
})( jQuery );


