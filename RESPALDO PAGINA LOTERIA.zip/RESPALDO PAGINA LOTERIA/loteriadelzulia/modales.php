<section id="modal1" class="modal">
		<div class="bg"></div>
		<div class="contenedor">
			<div class="contenido">
				<div class="controles">
					<ul>
						<li class="modal-close border-all"><i class="icon-cancel"></i></li>
					</ul>
				</div>
				<div class="content">
					<div class="noticias">
						<?php
							$i = 0;
							$class= "";
							$args = array(
							    'post_type' => 'post',
							    'numberposts' => 1,
							    'post_status' => null,
							    'category' => 3, // any parent
							    ); 
							$attachments = get_posts($args);
							if ($attachments) {
							    foreach ($attachments as $post) {
							        setup_postdata($post); ?>
										<div class="fondo <?php echo $class; ?>" style="background-image:url(<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>); background-size: 100%; background-position: 50%;">
										
										</div>
						<?php }
							}
						?>
					</div>
				</div>
			</div>
		</div>
	</section>