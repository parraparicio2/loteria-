<?php
/**
 * Template Name: Noticias
 *
 * Description: A page template that provides a key component of WordPress as a CMS
 * by meeting the need for a carefully crafted introductory page. The front page template
 * in Twenty Twelve consists of a page content area for adding text, images, video --
 * anything you'd like -- followed by front-page-only widgets in one or two columns.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Lotería del Zulia</title>
    <link rel="stylesheet" type="text/css" href="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/css/normalize.css">
    <link rel="stylesheet" type="text/css" href="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/css/style.css">
    <link rel="stylesheet" href="http://loteriadelzulia.gob.ve/wp-content/plugins/wp-pagenavi/pagenavi-css.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/css/icons_conalot.css">
    <link rel="stylesheet" href="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/css/animation.css"><!--[if IE 7]>
    <link rel="stylesheet" href="css/icons_conalot-ie7.css"><![endif]-->
    <script type="text/javascript" src="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/js/scripts.js"></script>
    <script type="text/javascript" src="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/js/jquery.simplyscroll.js"></script>
    <script type="text/javascript" src="http://loteriadelzulia.gob.ve/wp-content/themes/loteriadelzulia/js/jquery.tools.min.js"></script>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
    <section id="page">
        <nav>
            <div id="head">
                <?php include($_SERVER["DOCUMENT_ROOT"]."/wp-content/themes/loteriadelzulia/membrete.php"); ?>
                 <?php include( $_SERVER["DOCUMENT_ROOT"]."/wp-content/themes/loteriadelzulia/menu.php"); ?>
            </div>
        </nav>
        <section id="body">
            <div class="contenedor">
                <div class="noticias newsbg">
                    <div class="noticias-margin">
                        <ul>
                            <li class="td70">
                                <?php
                                    global $paged;
                                    if (get_query_var( 'paged' ))
                                        $my_page = get_query_var( 'paged' );
                                    else {
                                        if( get_query_var( 'page' ) )
                                            $my_page = get_query_var( 'page' );
                                        else
                                            $my_page = 1;
                                        set_query_var( 'paged', $my_page );
                                        $paged = $my_page;
                                    }
                                    $args = array(
                                    'post_type' => 'post',
                                    'numberposts' => -1,
                                    'post_status' => null,
                                    'category_name' => 'Noticias',
                                    'posts_per_page' => 5,
                                    'paged' => $my_page,
                                    ); 
                                    $my_query = new WP_Query( $args );
                                    while ($my_query->have_posts()) : $my_query->the_post(); ?> 
                                <div class="noticia-margin">
                                    <div class="noticia">
                                        <p class="title2"><?php the_title(); ?></p>
                                        <p class="footer"><?php the_date('F j, Y') ?></p>
                                        <div class="contenido">
                                            <a href="<?php the_permalink(); ?>"><img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>" class="imgnews" align="left"/></a><?php the_excerpt();  ?>
                                       </div>
                                       <div class="vermas-container"><p><a href="<?php the_permalink(); ?>" class="btn"><span>Leer más</span> <i class="icon-right-open"></i></a></p></div>
                                    </div> 
                                </div>
                               
                                <?php endwhile; ?>
                                 <div class="noticia-margin">
                                <?php
                                        wp_pagenavi( array( 'query' => $my_query ) );
                                        wp_reset_query();
                                    ?>
                                </div>
                            </li><!--
                         --><li class="td30">
                                <div class="noticia-margin-4">
                                    <a class="twitter-timeline"  href="https://twitter.com/LoteriaZuliaGBZ" data-widget-id="360477392604635136" height="1800px" >Tweets por @LoteriaZuliaGBZ</a>
                                    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="page-margin">
                    <div class="redes">
                        <p><a href="https://twitter.com/LoteriaZuliaGBZ"><i class="icon-twitter tw"></i></a> <a href="https://www.facebook.com/pages/Loter%C3%ADa-del-Zulia/138491336352632"><i class="icon-facebook fb"></i></a></p>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <p>Copyright (c) 2013. Lotería del Zulia. Todos los derechos reservados.</p>
        </footer>
    </section>
</body>
</html>