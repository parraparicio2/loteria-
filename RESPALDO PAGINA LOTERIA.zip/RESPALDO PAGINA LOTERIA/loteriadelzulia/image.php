<?php
/**
 * Template Name: News
 *
 * Description: Twenty Twelve loves the no-sidebar look as much as
 * you do. Use this page template to remove the sidebar from any page.
 *
 * Tip: to remove the sidebar from all posts and pages simply remove
 * any active widgets from the Main Sidebar area, and the sidebar will
 * disappear everywhere.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Lotería del Zulia</title>
    <link rel="stylesheet" type="text/css" href="../../wp-content/themes/loteriadelzulia/css/normalize.css">
    <link rel="stylesheet" type="text/css" href="../../wp-content/themes/loteriadelzulia/css/style.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../../wp-content/themes/loteriadelzulia/css/icons_conalot.css">
    <link rel="stylesheet" href="../../wp-content/themes/loteriadelzulia/css/animation.css"><!--[if IE 7]>
    <link rel="stylesheet" href="css/icons_conalot-ie7.css"><![endif]-->
    <script type="text/javascript" src="../../wp-content/themes/loteriadelzulia/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="../../wp-content/themes/loteriadelzulia/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="../../wp-content/themes/loteriadelzulia/js/scripts.js"></script>
    <script type="text/javascript" src="../../wp-content/themes/loteriadelzulia/js/jquery.simplyscroll.js"></script>
    <script type="text/javascript" src="../../wp-content/themes/loteriadelzulia/js/jquery.tools.min.js"></script>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
    <section id="page">
        <nav>
            <div id="head">
                <?php include($_SERVER["DOCUMENT_ROOT"]."/wp-content/themes/loteriadelzulia/membrete.php"); ?>
                <?php include( $_SERVER["DOCUMENT_ROOT"]."/wp-content/themes/loteriadelzulia/menu.php"); ?>
            </div>
        </nav>
        <section id="body">
            <div class="contenedor">
                <div class="noticias newsbg">
                    <div class="noticias-margin">
                        <ul>
                            <li class="td70">
                                <div class="noticia-margin">
                                   <?php while ( have_posts() ) : the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class( 'image-attachment' ); ?>>
                    <header class="entry-header">
                        <footer class="entry-meta">
                            <?php
                                $metadata = wp_get_attachment_metadata();
                                printf( __( '', 'twentytwelve' ),
                                    esc_attr( get_the_date( 'c' ) ),
                                    esc_html( get_the_date() ),
                                    esc_url( wp_get_attachment_url() ),
                                    $metadata['width'],
                                    $metadata['height'],
                                    esc_url( get_permalink( $post->post_parent ) ),
                                    esc_attr( strip_tags( get_the_title( $post->post_parent ) ) ),
                                    get_the_title( $post->post_parent )
                                );
                            ?>
                           
                        </footer><!-- .entry-meta -->

                        <nav id="image-navigation" class="navigation" role="navigation">
                            <span class="previous-image"><?php previous_image_link( false, __( '&larr; Previous', 'twentytwelve' ) ); ?></span>
                            <span class="next-image"><?php next_image_link( false, __( 'Next &rarr;', 'twentytwelve' ) ); ?></span>
                        </nav><!-- #image-navigation -->
                    </header><!-- .entry-header -->

                    <div class="entry-content">

                        <div class="entry-attachment">
                            <div class="attachment">
<?php
/**
 * Grab the IDs of all the image attachments in a gallery so we can get the URL of the next adjacent image in a gallery,
 * or the first image (if we're looking at the last image in a gallery), or, in a gallery of one, just the link to that image file
 */
$attachments = array_values( get_children( array( 'post_parent' => $post->post_parent, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID' ) ) );
foreach ( $attachments as $k => $attachment ) :
    if ( $attachment->ID == $post->ID )
        break;
endforeach;

$k++;
// If there is more than 1 attachment in a gallery
if ( count( $attachments ) > 1 ) :
    if ( isset( $attachments[ $k ] ) ) :
        // get the URL of the next image attachment
        $next_attachment_url = get_attachment_link( $attachments[ $k ]->ID );
    else :
        // or get the URL of the first image attachment
        $next_attachment_url = get_attachment_link( $attachments[ 0 ]->ID );
    endif;
else :
    // or, if there's only 1 image, get the URL of the image
    $next_attachment_url = wp_get_attachment_url();
endif;
?>
                                <a href="<?php echo esc_url( $next_attachment_url ); ?>" title="<?php the_title_attribute(); ?>" rel="attachment"><?php
                                $attachment_size = apply_filters( 'twentytwelve_attachment_size', array( 960, 960 ) );
                                echo wp_get_attachment_image( $post->ID, $attachment_size );
                                ?></a>

                                <?php if ( ! empty( $post->post_excerpt ) ) : ?>
                                <div class="entry-caption">
                                    <?php the_excerpt(); ?>
                                </div>
                                <?php endif; ?>
                            </div><!-- .attachment -->

                        </div><!-- .entry-attachment -->

                        <div class="entry-description">
                            <?php the_content(); ?>
                            <?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) ); ?>
                        </div><!-- .entry-description -->

                    </div><!-- .entry-content -->

                </article><!-- #post -->

            <?php endwhile; // end of the loop. ?>
                                </div>
                            </li><!--
                         --><li class="td30">
                                <div class="noticia-margin-4">
                                    <a class="twitter-timeline"  href="https://twitter.com/LoteriaZuliaGBZ" data-widget-id="360477392604635136" height="800px" >Tweets por @LoteriaZuliaGBZ</a>
                                    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="page-margin">
                    <div class="redes">
                        <p><a href="https://twitter.com/LoteriaZuliaGBZ"><i class="icon-twitter tw"></i></a> <a href="https://www.facebook.com/pages/Loter%C3%ADa-del-Zulia/138491336352632"><i class="icon-facebook fb"></i></a></p>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <p>Copyright (c) 2013. Lotería del Zulia. Todos los derechos reservados.</p>
        </footer>
    </section>
</body>
</html>